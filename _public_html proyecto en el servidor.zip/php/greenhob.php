<?php
	/* $host="localhost";
	$usuario="root";
	$password="1234";
	$bbdd="HOBBIE"; */
	
	
	$host="localhost";
	$usuario="u720382761_administrador";
	$password="Legolas_89";
	$bbdd="u720382761_hobbie";
?>